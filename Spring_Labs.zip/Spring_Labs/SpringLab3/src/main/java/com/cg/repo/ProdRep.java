package com.cg.repo;

import java.util.List;

import com.cg.entity.Prod;

public interface ProdRep {

	
	void saveProduct(Prod product);

}
