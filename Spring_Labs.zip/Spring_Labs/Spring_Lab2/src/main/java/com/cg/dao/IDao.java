package com.cg.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.Trainee;

public interface IDao extends CrudRepository<Trainee, Integer> {

}
