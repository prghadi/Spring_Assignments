package com.cg.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.ServiceImpl;


@Controller
public class TraineeController {


	@Autowired
	ServiceImpl service;
	
	Trainee trainee;
	
	@RequestMapping("/")
	public String login(Model model) {
		model.addAttribute("login",new Login());
		return "login";
	}
	
	@RequestMapping(value = "/checkLogin")
	public String checkLogin(Login login) {
		// Logic to validate userName and password against database
		if(login.getUserName().equalsIgnoreCase("pranita") && login.getPassword().equalsIgnoreCase("123456"))
			return "loginSuccess";
		else {
			return "login";
		}
	}
	
	@RequestMapping(value="/add")
	public String addTrainee(Model model) {
		model.addAttribute("addTrainee",new Trainee());
		return "addTrainee";
	}
	
	@RequestMapping("/addDB")
	public String addTrainee(@ModelAttribute("")Trainee addnew, Model model) {
		service.saveTrainee(addnew);
		return "loginSuccess";
	}
	
	@RequestMapping(value="/delete")
	public String deletepage(Model model) {
		return "delete";
	}
	
	@RequestMapping("/search")
	public String retrieveTodelete(Model model, @RequestParam("traineeId") int traineeId) {
		trainee = service.getTrainee(traineeId);
		model.addAttribute(trainee);
		return "delete";
	}
	
	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model,Trainee trainee) {
		service.deleteTrainee(trainee);
		return "loginSuccess";
	}
	
	@RequestMapping(value="/retrieve")
	public String retrieveDetails(Model model) {
		return "retrieve";
	}
	
	@RequestMapping("/retieveSingle")
	public String retrieveSingle(Model model, @RequestParam("traineeId") int traineeId) {
		trainee = service.getTrainee(traineeId);
		model.addAttribute(trainee);
		return "retrieve";
	}
	
	@RequestMapping("/menu")
	public String retrieveTrainee(Model model,Trainee trainee) {
		service.deleteTrainee(trainee);
		return "loginSuccess";
	}
	
	
	

//
//	@PutMapping(path = "/update/{id}", consumes = "application/json")
//	public Trainee updateTrainee(@PathVariable("id") int id, @RequestBody Trainee t) {
//		return service.updateTrainee(t, id);
//
//	}
//	
//	@GetMapping(path = "/trainee/{id}")
//	public ResponseEntity<Trainee> getTrainee(@PathVariable("id") int id) {
//		try {
//			Trainee t = service.getTrainee(id);
//			return new ResponseEntity<Trainee>(t, HttpStatus.OK);
//		} catch (NoSuchElementException e) {
//			return new ResponseEntity("No Trainee found", HttpStatus.NOT_FOUND);
//		}
//	}
//	
//	@GetMapping("/alltrainee")
//	public Iterable<Trainee> getAll() {
//		return service.getAll();
//	}	

}
