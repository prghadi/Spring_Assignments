package com.cg.dao;

/**
 * @author prghadi
 * version1.0
 * This is the public class of Dao layer
 */
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Empl;

public class DaoImpl implements DaoI{

	// Get list of employees
	List<Empl> list = new ArrayList<Empl>();
	ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
	Empl emp= (Empl) ctx.getBean("emp");
	Empl emp2= (Empl) ctx.getBean("emp2");
//	Employee emp5=(Employee) ctx.getBean("name");
	
	// Add employees
	@Override
	public void addAll() {
		list.add(emp);
		list.add(emp2);
		
	}
	
	// Find Employee
	@Override
	public Empl findEmployee(int id) {
		for(Empl e : list) {
			if(e.getEmpId()==id)
				return e;
			else 
				return null;
		}
		return null;
	}	
	
}
