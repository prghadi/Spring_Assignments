package com.cg.bean;

/**
 * @author prghadi
 *@version1.0
 *This is the public class of Empl
 */
public class Empl {

	// Declare attributes
	private int empId;
	private String empName;
	private double salary;

	// Getters and Setters
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
// Generate toString method to display data of Empl
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", salary=" + salary + "]";
	}
	
	
	
}
