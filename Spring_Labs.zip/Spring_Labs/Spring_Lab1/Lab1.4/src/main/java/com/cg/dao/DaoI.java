package com.cg.dao;

/**
 * @author prghadi
 * vesrion1.0
 * This is the public interface of Dao Layer
 */
import com.cg.bean.Empl;

public interface DaoI {

	// Method to addAll employee
	public void addAll();
	
	// Method to find Employee
	public Empl findEmployee(int id);
	
}
