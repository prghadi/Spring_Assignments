package com.cg.bean;

/**
 * @author prghadi
 * @version1.0
 * This is the public main class of Emp
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmpMain {

	public static void main(String[] args) {
		
		// Declare ApplicationContext
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		SBU sb = (SBU) ctx.getBean("sbu");
	//	Employee emp = (Employee) ctx.getBean("employee");
		
		System.out.println("SBU Details");
	
		System.out.println(sb);
		System.out.println("Employee Details");
		
		System.out.println(sb.getEmpList());
	}
}