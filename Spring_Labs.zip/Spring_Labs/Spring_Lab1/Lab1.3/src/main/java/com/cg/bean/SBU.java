package com.cg.bean;

/**
 * @author prghadi
 * @version1.0
 * This is the public class of sbu
 */
import java.util.List;

public class SBU {

	// Declare attributes
	private int sbuCode;
	private String sbuName;
	private String sbuHead;
	
	// Get list of employees
	List<Empl>empList;

	// Getters and Setters
	public int getSbuCode() {
		return sbuCode;
	}

	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	public List<Empl> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Empl> empList) {
		this.empList = empList;
	}
// Generate to String method to display data of Emp
	@Override
	public String toString() {
		return "SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead +"]";
	}
	
	
	
}
