package com.cg.bean;

/**
 * @author prghadi
 * @version1.0
 * This is the main public class of EmpMain
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class EmpMain {

	public static void main(String[] args) {
		
		// Declare ApplicationContext 
		ApplicationContext ctx = new ClassPathXmlApplicationContext("details.xml");
		Empl emp = (Empl) ctx.getBean("employee");
		
		System.out.println("Employee Details");
		
		System.out.println(emp);
	}
}