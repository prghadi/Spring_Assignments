package com.cg.bean;

/**
 * @author prghadi
 * @vrsion1.0
 * This is the public of EmpMain
 */
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EMain {
	
	

	public static void main(String[] args) {
		
		// Declare ApplicationContext to provide configuration
		ApplicationContext ctx = new ClassPathXmlApplicationContext("employee.xml");
		Empl emp = (Empl) ctx.getBean("employee");
		
		
		System.out.println("Employee Details");
		
		System.out.println("Employee ID : " + emp.getEmpId());
		System.out.println("Employee Name : " + emp.getName());
		System.out.println("Employee Salary : " + emp.getSalary());
		System.out.println("Employee BU : " + emp.getBU());
		System.out.println("Employee Age : " + emp.getAge());
	}
}
